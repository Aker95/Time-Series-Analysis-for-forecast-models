function [AICM,BICM] = Garch_Elec(info,mdl)
ARC=5;
GA=5;
aicmin=Inf;
bicmin=Inf;
l=length(info);


for A=1:ARC
    for G=0:GA
        CondVarMdl = garch(G,A);
        mdl.Variance = CondVarMdl;
        [EstMdl,~,Logl] = estimate(mdl,info);
        [aic,bic] = aicbic(Logl,(G+A),l);
        if aic<aicmin
            aicmin=aic;
            AICM=[G,A];
        end
        if bic<bicmin
            bicmin=aic;
            BICM=[G,A];
        end
    end
end