#############################################
# Taller 3, Punto 1.3
# Integrantes:
# Nicolas Akerman - 201423015
# Andrés Chaparro - 201813157
# Edward Gómez - 202020028
# Jesús Cepeda - 201910058
# Sebastián Cifuentes - 201817089
# Sergio Pinila - 201814755
#############################################

# DF y Normal
R <- 100000
matriz <- matrix(NA, nrow = 1000, ncol = R)
set.seed(1234)
for (i in 1:1000) {
  matriz[i, ] <- rnorm(R, 0, 1)
}

dim(matriz)

y <- matrix(NA, nrow = 1001, ncol = R)
y[1, ] <- 100

for (j in 2:1001) {
  k <- j - 1
  y[j, ] <- matriz[k, ] + y[k, ]
}

DF <- c()
for(i in 1:R){
  modelo <- lm(matriz[, i] ~ y[1:1000, i])
  se <- sqrt(diag(vcov(modelo)))
  DF[i] <- modelo$coefficients[2] / se[2]
  if((100*(i/R)) %% 10 == 0){
    print(paste0((100*(i/R)), " % completado"))
  }
}

DF <- sort(DF)
DF1 <- as.vector(round(DF, digits = 4))
which(DF1 == - 1.2816) / R # 64%
which(DF1 == - 2.5683) / R # 10%

plot(density(rnorm(R,0,1)))
lines(density(DF))


